@extends('layouts.app')

@section('content')
<list-component></list-component>
@endsection